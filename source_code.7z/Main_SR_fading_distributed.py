import matplotlib.pyplot as plt
import numpy as np
import random
import json
import math, generate_channel_gain, build_model
import scipy.special
from itertools import product
import itertools
from collections import deque
from keras.models import load_model

# average received SNR in dB

No_user = 3
No_BD = 3

threshold_dB = 5  # dB
threshold = 10 ** (threshold_dB / 10)  # dB
reflection_coef = 0.8

Period_ratio = 50

T_time_slot = 0.2 * 10 ** (-3)  # duration of each time slot
n_symbols = 5000  # T_time_slot/T_symbol

fmhz = 2400
Gt = 2.5
Gr = 2.5

n_element_state = No_user + 4

Memory_pool_set = []
for u in range (0, No_BD):
    Memory_pool = deque()
    Memory_pool_set.append(Memory_pool)

# n_element_state=1+3*No_user ## state(t)=(channel gain(t), action(t-1), success/failed, signal strength(t-1), interference(t-1))
n_mini_batch = 64
n_memory_size = 800
n_training = 5000
i_observation = 0

n_network_input = (n_element_state,)
# print(n_network_input)

model_eval_set = []
model_tar_set = []
for u in range (0, No_BD):
    model_eval = build_model.build_model(n_network_input)
    model_eval.save('model.h5')
    model_eval_set.append(model_eval)
    model_tar = load_model('model.h5')
    model_tar_set.append(model_tar)

epsilon = 0.3
gamma = 0.3
lambda_epsilon = 0.005
epsilon_min = 0.005
loss = []

# Action
Action_set = list(range(1, No_user + 1))

# %%generate users and BDs

# boundary = 100
# #boundary1 = 30
# inner_region = 20
#
# loc_x = np.random.rand(No_user)
# for u in range(0,No_user):
#     if loc_x[u]>0.5:
#         loc_x[u] = 1
#     else:
#         loc_x[u] = -1
# loc_y = np.random.rand(No_user)
# for u in range(0,No_user):
#     if loc_y[u]>0.5:
#         loc_y[u] = 1
#     else:
#         loc_y[u] = -1
# loc_x_BD = np.random.rand(No_BD)
# for u in range(0,No_BD):
#     if loc_x_BD[u]>0.5:
#         loc_x_BD[u] = 1
#     else:
#         loc_x_BD[u] = -1
# loc_y_BD = np.random.rand(No_BD)
# for u in range(0,No_BD):
#     if loc_y_BD[u]>0.5:
#         loc_y_BD[u] = 1
#     else:
#         loc_y_BD[u] = -1
# location_x = loc_x*np.random.uniform(inner_region, boundary, No_user)
# location_y = loc_y*np.random.uniform(inner_region, boundary, No_user)
# location_x_BD = loc_x*np.random.uniform(inner_region, boundary, No_BD)
# location_y_BD = loc_y*np.random.uniform(inner_region, boundary, No_BD)
# location_x_BD = np.zeros(No_BD)
# location_y_BD = np.zeros(No_BD)
# for u in range(0,No_user):
#     location_x_BD[u] = loc_x_BD[u] * np.random.uniform(0,inner_region)+location_x[u]
#     location_y_BD[u] = loc_y_BD[u]*np.random.uniform(0,inner_region)+location_y[u]
#
# plt.figure(1)
# plt.scatter(location_x, location_y, s=200, label = '$User$', c = 'blue', marker='.', alpha = None, edgecolors= 'white')
# plt.scatter(location_x_BD, location_y_BD, s=200, label = '$BD$', c = 'red', marker='.', alpha = None, edgecolors= 'white')
# plt.legend()
# plt.show()

filename = 'location_x.json'
with open(filename, 'r') as f:
    location_x = json.load(f)

location_x = np.array(location_x)

filename = 'location_y.json'
with open(filename, 'r') as f:
    location_y = json.load(f)

location_y = np.array(location_y)

filename = 'location_x_BD.json'
with open(filename, 'r') as f:
    location_x_BD = json.load(f)

location_x_BD = np.array(location_x_BD)

filename = 'location_y_BD.json'
with open(filename, 'r') as f:
    location_y_BD = json.load(f)

location_y_BD = np.array(location_y_BD)

# Distance
distance_user = np.sqrt(location_x ** 2 + location_y ** 2)
distance_BD = np.sqrt(location_x_BD ** 2 + location_y_BD ** 2)
distance_BD_user = np.array([], dtype=float)
for u in range(0, No_BD):
    for v in range(0, No_user):
        distance_BD_user_new = math.sqrt(
            (location_x_BD[u] - location_x[v]) ** 2 + (location_y_BD[u] - location_y[v]) ** 2)
        distance_BD_user = np.append(distance_BD_user, distance_BD_user_new)

# %%Path Loss
L = (32.45 + 20 * math.log(fmhz, 10) - Gt - Gr)
path_loss_user_dB = L + 20 * np.log10(distance_user / 1000)
path_loss_BD_dB = L + 20 * np.log10(distance_BD / 1000)
path_loss_BD_user_dB = L + 20 * np.log10(distance_BD_user / 1000)

Ptx_cell_Avg_dB = 40  # dBm
Noise = -114  # -114dBm

SNR_user_Avg_dB = Ptx_cell_Avg_dB - path_loss_user_dB - Noise  # dB
SNR_user_Avg = 10 ** (SNR_user_Avg_dB / 10)

SNR_BD_Avg = np.array([], dtype=float)
for u in range(0, No_BD):
    SNR_BD_Avg_dB = Ptx_cell_Avg_dB - path_loss_BD_dB[u] - Noise - path_loss_BD_user_dB[
                                                                   (u) * No_user:(u + 1) * No_user]  # dB
    SNR_BD_Avg = np.append(SNR_BD_Avg, 10 ** (SNR_BD_Avg_dB / 10))

# %%Channel Information
Channel_gain_BD_user_old = np.array([], dtype=float)
Fading_BD_user_old = np.array([], dtype=complex)
for u in range(0, No_BD):
    for v in range(0, No_user):
        Fading_BD_user = complex(2 ** (1 / 2) / 2 * random.gauss(0, 1), 2 ** (1 / 2) / 2 * random.gauss(0, 1))
        Channel_gain_BD_user, Fading_BD_user = generate_channel_gain.generate_channel_gain(SNR_BD_Avg[u * No_user + v],
                                                                                           Fading_BD_user, T_time_slot)
        Channel_gain_BD_user_old = np.append(Channel_gain_BD_user_old, float(Channel_gain_BD_user))
        Fading_BD_user_old = np.append(Fading_BD_user_old, complex(Fading_BD_user))

Channel_gain_BD_user_last2 = Channel_gain_BD_user_old

Channel_gain_BD_user_new = np.array([], dtype=float)
Fading_BD_user_new = np.array([], dtype=complex)
for u in range(0, No_BD):
    for v in range(0, No_user):
        Channel_gain_BD_user, Fading_BD_user = generate_channel_gain.generate_channel_gain(SNR_BD_Avg[u * No_user + v],
                                                                                           Fading_BD_user_old[
                                                                                               u * No_user + v],
                                                                                           T_time_slot)
        Channel_gain_BD_user_new = np.append(Channel_gain_BD_user_new, float(Channel_gain_BD_user))
        Fading_BD_user_new = np.append(Fading_BD_user_new, complex(Fading_BD_user))

Fading_BD_user_old = Fading_BD_user_new
Channel_gain_BD_user_old = Channel_gain_BD_user_new

Channel_gain_BD_user_last1 = Channel_gain_BD_user_old

Channel_gain_BD_user_new = np.array([], dtype=float)
Fading_BD_user_new = np.array([], dtype=complex)
for u in range(0, No_BD):
    for v in range(0, No_user):
        Channel_gain_BD_user, Fading_BD_user = generate_channel_gain.generate_channel_gain(SNR_BD_Avg[u * No_user + v],
                                                                                           Fading_BD_user_old[
                                                                                               u * No_user + v],
                                                                                           T_time_slot)
        Channel_gain_BD_user_new = np.append(Channel_gain_BD_user_new, float(Channel_gain_BD_user))
        Fading_BD_user_new = np.append(Fading_BD_user_new, complex(Fading_BD_user))

# Channel from BS to user
Channel_gain_BS_user = np.array([], dtype=float)
Fading_BS_user_old = np.array([], dtype=complex)
for u in range(0, No_user):
    Fading_BS_user = complex(2 ** (1 / 2) / 2 * random.gauss(0, 1), 2 ** (1 / 2) / 2 * random.gauss(0, 1))
    Channel_gain_BS_user_new = SNR_user_Avg[u] * (Fading_BS_user.real ** 2 + Fading_BS_user.imag ** 2)
    Channel_gain_BS_user = np.append(Channel_gain_BS_user, float(Channel_gain_BS_user_new))
    Fading_BS_user_old = np.append(Fading_BS_user_old, complex(Fading_BS_user))

Channel_gain_BS_user = np.array([], dtype=float)
Fading_BS_user_new = np.array([], dtype=complex)
for u in range(0, No_user):
    Channel_gain_BS_user_new, Fading_BS_user = generate_channel_gain.generate_channel_gain(SNR_user_Avg[u],
                                                                                           Fading_BS_user_old[u],
                                                                                           T_time_slot)
    Channel_gain_BS_user = np.append(Channel_gain_BS_user, float(Channel_gain_BS_user_new))
    Fading_BS_user_new = np.append(Fading_BS_user_new, complex(Fading_BS_user))

# Channel from BS to BD without transmission power
Channel_gain_BS_BD = np.array([], dtype=float)
Fading_BS_BD_old = np.array([], dtype=complex)
for u in range(0, No_BD):
    Fading_BS_BD = complex(2 ** (1 / 2) / 2 * random.gauss(0, 1), 2 ** (1 / 2) / 2 * random.gauss(0, 1))
    Channel_gain_BS_BD_new, Fading_BS_BD = generate_channel_gain.generate_channel_gain(1, Fading_BS_BD, T_time_slot)
    Channel_gain_BS_BD = np.append(Channel_gain_BS_BD, float(Channel_gain_BS_BD_new))
    Fading_BS_BD_old = np.append(Fading_BS_BD_old, complex(Fading_BS_BD))

Channel_gain_BS_BD = np.array([], dtype=float)
Fading_BS_BD_new = np.array([], dtype=complex)
for u in range(0, No_BD):
    Channel_gain_BS_BD_new, Fading_BS_BD = generate_channel_gain.generate_channel_gain(1, Fading_BS_BD_old[u],
                                                                                       T_time_slot)
    Channel_gain_BS_BD = np.append(Channel_gain_BS_BD, float(Channel_gain_BS_BD_new))
    Fading_BS_BD_new = np.append(Fading_BS_BD_new, complex(Fading_BS_BD))

# %%Action
Action_Index = np.zeros(No_BD)
Action_Index = np.random.randint(0, len(Action_set) - 1, No_BD)

# %%reward
Channel_gain_BD = np.zeros((No_BD, No_user))
for u in range(0, No_BD):
    for v in range(0, No_user):
        Channel_gain_BD[u, v] = Channel_gain_BD_user_new[u * No_user + v] * Channel_gain_BS_BD[u]

Pair = np.zeros((No_BD, No_BD))
for u in range(0, No_BD):
    for v in range(u + 1, No_BD):
        if Action_Index[u] == Action_Index[v]:
            if Channel_gain_BD[u, Action_Index[u]] > Channel_gain_BD[v, Action_Index[v]]:
                Pair[u, v] = 1
            else:
                Pair[v, u] = 1

Interfered_BD = np.zeros(No_BD)
for u in range(0, No_BD):
    Interfered_BD[u] = np.dot(Pair[u, :], Channel_gain_BD[:, Action_Index[u]])

Modified_pair = np.zeros((No_BD, No_BD ** 2))
for u in range(0, No_BD):
    Modified_pair[0:No_BD, u * No_user:(u + 1) * No_user] = Pair
    Modified_pair[:, u * No_user + u] = 0

reward = np.array([], dtype=float)
throughput_new = np.zeros(No_BD)
for u in range(0, No_BD):
    backscatter_SNR = Period_ratio * reflection_coef ** 2 * Channel_gain_BD[u, Action_Index[u]] / (
                1 + Period_ratio * Interfered_BD[u])
    #    if backscatter_SNR>threshold:
    throughput_new[u] = math.log(1 + backscatter_SNR, 2)
#    else:
#        reward_new = 0
throughput_without_new = np.zeros(No_BD)
interference_pi = np.zeros(No_BD)
for u in range(0, No_BD):
    for v in range(0, No_BD):
        Interfered_without_BD = np.dot(Modified_pair[v, u * No_user:(u + 1) * No_user],
                                       Channel_gain_BD[:, Action_Index[v]])
        interference_SNR = Period_ratio * reflection_coef ** 2 * Channel_gain_BD[v, Action_Index[v]] / (
                    1 + Period_ratio * Interfered_without_BD)
        throughput_without_new[v] = math.log(1 + interference_SNR, 2)
    interference_pi[u] = sum(throughput_without_new - throughput_new)
reward_new = throughput_new - interference_pi
reward = np.append(reward, reward_new)

# %%state
Interfer_BD = np.zeros(No_BD)
for u in range(0, No_BD):
    Interfer_BD[u] = np.sum(Pair[:, u] * Channel_gain_BD[u, Action_Index[u]])

state_old = np.zeros((n_element_state, No_BD))

for u in range(0, No_BD):
    state_old[0, u] = Interfered_BD[u] / max(SNR_BD_Avg)
    state_old[1, u] = Interfer_BD[u] / max(SNR_BD_Avg)
    state_old[2, u] = Action_Index[u] / No_user
    state_old[3:No_user + 3, u] = Channel_gain_BS_BD[u] * Channel_gain_BD_user_last1[
                                                          u * No_user:(u + 1) * No_user] / max(SNR_BD_Avg)
    #    state_old[No_user+3:2*No_user+3,u] = Channel_gain_BS_BD[u]* Channel_gain_BD_user_last2[u*No_user:(u+1)*No_user]/SNR_BD_Avg[u]
    state_old[No_user + 3, u] = u / No_BD

# state_old[0:No_user]=Channel_gain_BD_user_last2/Prx_cell_Avg
# state_old[No_user:2*No_user]=Channel_gain_BD_user_last1/Prx_cell_Avg

state_new = state_old

# %%DRL

# No_user_drl=[]
# No_user_optimal = []
throughput_drl = []
throughput_optimal = []
throughput_optimal_sub = []
# No_user_random = []
throughput_random = []
while (i_observation < n_training):
    print(i_observation)
    if i_observation < n_mini_batch:
        Action_Index = np.zeros(No_BD)
        Action_Index = np.random.randint(0, len(Action_set) - 1, No_BD)
    else:
        epsilon = max(epsilon_min, (1 - lambda_epsilon) * epsilon)
        if random.random() < epsilon:
            Action_Index = np.zeros(No_BD)
            Action_Index = np.random.randint(0, len(Action_set) - 1, No_BD)
        else:
            Action_Index = np.array([], dtype=int)
            for u in range(0, No_BD):
                State_slot_t_temp = list(state_new[:, u])
                State_slot_t_temp_shape = (1, n_element_state)
                State_slot_t_temp = np.reshape(State_slot_t_temp, State_slot_t_temp_shape)
                q = model_eval_set[u].predict(State_slot_t_temp)
                # print('q')
                #  print(q)
                max_Q = np.argmax(q)
                Action_Index_new = max_Q
                Action_Index = np.append(Action_Index, Action_Index_new)

    # %% channel
    Fading_BD_user_old = Fading_BD_user_new
    Channel_gain_BD_user_old = Channel_gain_BD_user_new
    Channel_gain_BD_user_new = np.array([], dtype=float)
    Fading_BD_user_new = np.array([], dtype=complex)
    for u in range(0, No_BD):
        for v in range(0, No_user):
            Channel_gain_BD_user, Fading_BD_user = generate_channel_gain.generate_channel_gain(
                SNR_BD_Avg[u * No_user + v], Fading_BD_user_old[u * No_user + v], T_time_slot)
            Channel_gain_BD_user_new = np.append(Channel_gain_BD_user_new, float(Channel_gain_BD_user))
            Fading_BD_user_new = np.append(Fading_BD_user_new, complex(Fading_BD_user))

    for u in range(0, No_BD):
        Channel_gain_BD_user_last2[u * No_user + Action_Index[u]] = Channel_gain_BD_user_last1[
            u * No_user + Action_Index[u]]
        Channel_gain_BD_user_last1[u * No_user + Action_Index[u]] = Channel_gain_BD_user_old[
            u * No_user + Action_Index[u]]

    # Channel from BS to user
    Fading_BS_user_old = Fading_BS_user_new
    Channel_gain_BS_user = np.array([], dtype=float)
    Fading_BS_user_new = np.array([], dtype=complex)
    for u in range(0, No_user):
        Channel_gain_BS_user_new, Fading_BS_user = generate_channel_gain.generate_channel_gain(SNR_user_Avg[u],
                                                                                               Fading_BS_user_old[u],
                                                                                               T_time_slot)
        Channel_gain_BS_user = np.append(Channel_gain_BS_user, float(Channel_gain_BS_user_new))
        Fading_BS_user_new = np.append(Fading_BS_user_new, complex(Fading_BS_user))

    # Channel from BS to BD without transmission power
    Fading_BS_BD_old = Fading_BS_BD_new
    Channel_gain_BS_BD = np.array([], dtype=float)
    Fading_BS_BD_new = np.array([], dtype=complex)
    for u in range(0, No_BD):
        Channel_gain_BS_BD_new, Fading_BS_BD = generate_channel_gain.generate_channel_gain(1, Fading_BS_BD_old[u],
                                                                                           T_time_slot)
        Channel_gain_BS_BD = np.append(Channel_gain_BS_BD, float(Channel_gain_BS_BD_new))
        Fading_BS_BD_new = np.append(Fading_BS_BD_new, complex(Fading_BS_BD))

    # %% calculate DRL reward

    Channel_gain_BD = np.zeros((No_BD, No_user))
    for u in range(0, No_BD):
        for v in range(0, No_user):
            Channel_gain_BD[u, v] = Channel_gain_BD_user_new[u * No_user + v] * Channel_gain_BS_BD[u]

    Pair = np.zeros((No_BD, No_BD))
    for u in range(0, No_BD):
        for v in range(u + 1, No_BD):
            if Action_Index[u] == Action_Index[v]:
                if Channel_gain_BD[u, Action_Index[u]] > Channel_gain_BD[v, Action_Index[v]]:
                    Pair[u, v] = 1
                else:
                    Pair[v, u] = 1

    Interfered_BD = np.zeros(No_BD)
    for u in range(0, No_BD):
        Interfered_BD[u] = np.dot(Pair[u, :], Channel_gain_BD[:, Action_Index[u]])

    #    reward = np.array([], dtype=float)
    #    for u in range(0,No_BD):
    #    #    related_SNR = reflection_coef**2*Channel_gain_BD_user_new[u*No_user+Action_Index]* Channel_gain_BS_BD[u]/Channel_gain_BS_user[Action_Index]
    #        backscatter_SNR = Period_ratio*reflection_coef**2*SNR_BD_Avg[u*No_user+Action_Index[u]]/(1+Period_ratio*Interfered_BD[u])
    #        if backscatter_SNR>=threshold:
    #            reward_new = math.log(1+backscatter_SNR,2)
    #        else:
    #            reward_new = 0
    #        reward = np.append(reward, reward_new)

    Modified_pair = np.zeros((No_BD, No_BD ** 2))
    for u in range(0, No_BD):
        Modified_pair[0:No_BD, u * No_user:(u + 1) * No_user] = Pair
        Modified_pair[:, u * No_user + u] = 0

    reward = np.array([], dtype=float)
    throughput_new = np.zeros(No_BD)
    for u in range(0, No_BD):
        backscatter_SNR = Period_ratio * reflection_coef ** 2 * Channel_gain_BD[u, Action_Index[u]] / (
                    1 + Period_ratio * Interfered_BD[u])
        #    if backscatter_SNR>threshold:
        throughput_new[u] = math.log(1 + backscatter_SNR, 2)
    #    else:
    #        reward_new = 0
    throughput_without_new = np.zeros(No_BD)
    interference_pi = np.zeros(No_BD)
    for u in range(0, No_BD):
        for v in range(0, No_BD):
            Interfered_without_BD = np.dot(Modified_pair[v, u * No_user:(u + 1) * No_user],
                                           Channel_gain_BD[:, Action_Index[v]])
            interference_SNR = Period_ratio * reflection_coef ** 2 * Channel_gain_BD[v, Action_Index[v]] / (
                        1 + Period_ratio * Interfered_without_BD)
            throughput_without_new[v] = math.log(1 + interference_SNR, 2)
        interference_pi[u] = sum(throughput_without_new - throughput_new)
    reward_new = throughput_new - interference_pi
    reward = np.append(reward, reward_new)

    # %% calculate DRL access number

    #    No_user_drl[] = np.append(No_user_drl, int(Action_Index))
    throughput_drl = np.append(throughput_drl, sum(throughput_new))

    # %%calculate optimal access number
    # A_optimal = []
    A_optimal_set = list(product(list(range(0, No_user)), repeat=No_user))
    # num=len(num_list)
    #    res_list=list(product(num_list,repeat=num))
    Channel_gain_BD_sub = np.zeros((No_BD, No_user))
    for u in range(0,No_BD):
        for v in range(0, No_user):
            Channel_gain_BD_sub[u,v] = Channel_gain_BD_user_last1[u*No_user+v]* Channel_gain_BS_BD[u]


    throughput_temp = np.zeros(len(A_optimal_set))
    throughput_temp_sub = np.zeros(len(A_optimal_set))
    for w in range(0,len(A_optimal_set)):
        Action_Index_optimal = A_optimal_set[w]
        Pair_optimal =  np.zeros((No_BD,No_BD))
        Pair_optimal_sub = np.zeros((No_BD, No_BD))
        for u in range(0, No_BD):
            for v in range(u+1,No_BD):
                if Action_Index_optimal[u]==Action_Index_optimal[v]:
                    if  Channel_gain_BD[u,Action_Index_optimal[u]]>Channel_gain_BD[v,Action_Index_optimal[v]]:
                        Pair_optimal[u,v] = 1
                    else:
                        Pair_optimal[v,u] = 1
                    if Channel_gain_BD_sub[u,Action_Index_optimal[u]]>Channel_gain_BD_sub[v,Action_Index_optimal[v]]:
                        Pair_optimal_sub[u, v] = 1
                    else:
                        Pair_optimal_sub[v, u] = 1
        Interfered_BD_optimal = np.zeros(No_BD)
        Interfered_BD_optimal_sub = np.zeros(No_BD)
        for u in range(0,No_BD):
            Interfered_BD_optimal[u] = np.dot(Pair_optimal[u,:],Channel_gain_BD[:,Action_Index_optimal[u]])
            Interfered_BD_optimal_sub[u] = np.dot(Pair_optimal_sub[u,:],Channel_gain_BD_sub[:,Action_Index_optimal[u]])
        throughput_optimal_new = np.zeros(No_BD)
        throughput_optimal_new_sub = np.zeros(No_BD)
        for u in range(0,No_BD):
            backscatter_SNR_optimal = Period_ratio*reflection_coef**2* Channel_gain_BD[u,Action_Index_optimal[u]]/(1+Period_ratio*Interfered_BD_optimal[u])
            throughput_optimal_new[u] = math.log(1+backscatter_SNR_optimal,2)

            backscatter_SNR_optimal_sub = Period_ratio * reflection_coef ** 2 * Channel_gain_BD_sub[
                u, Action_Index_optimal[u]] / (1 + Period_ratio * Interfered_BD_optimal_sub[u])
            throughput_optimal_new_sub[u] = math.log(1 + backscatter_SNR_optimal_sub, 2)
        throughput_temp[w] = sum(throughput_optimal_new)
        throughput_temp_sub[w] = sum(throughput_optimal_new_sub)
    throughput_optimal = np.append(throughput_optimal, max(throughput_temp))
    throughput_optimal_sub = np.append(throughput_optimal_sub, throughput_temp[np.argmax(throughput_temp_sub)])

    #

    #    related_SNR_optimal = reflection_coef**2*Channel_gain_BD_user_new* Channel_gain_BS_BD/Channel_gain_BS_user
    #    backscatter_SNR_optimal = Period_ratio*reflection_coef**2*Channel_gain_BD_user_new* Channel_gain_BS_BD
    #    No_user_optimal_new = np.argmax(backscatter_SNR_optimal)
    #    No_user_optimal = np.append(No_user_optimal, No_user_optimal_new)
    #    if related_SNR_optimal[No_user_optimal_new]>=threshold:
    #        throughput_optimal_new = math.log(1+backscatter_SNR_optimal[No_user_optimal_new],2)
    #    else:
    #        throughput_optimal_new = 0
    #    throughput_optimal = np.append(throughput_optimal, throughput_optimal_new)

    # %% calculate random access number

    Action_Index_random = np.zeros(No_BD)
    Action_Index_random = np.random.randint(0, len(Action_set) - 1, No_BD)

    Pair_random = np.zeros((No_BD, No_BD))
    for u in range(0, No_BD):
        for v in range(u + 1, No_BD):
            if Action_Index_random[u] == Action_Index_random[v]:
                if Channel_gain_BD[u, Action_Index_random[u]] > Channel_gain_BD[v, Action_Index_random[v]]:
                    Pair_random[u, v] = 1
                else:
                    Pair_random[v, u] = 1

    Interfered_BD_random = np.zeros(No_BD)
    for u in range(0, No_BD):
        Interfered_BD_random[u] = np.dot(Pair_random[u, :], Channel_gain_BD[:, Action_Index_random[u]])
    throughput_random_new = np.zeros(No_BD)
    for u in range(0, No_BD):
        backscatter_SNR_random = Period_ratio * reflection_coef ** 2 * Channel_gain_BD[u, Action_Index_random[u]] / (
                    1 + Period_ratio * Interfered_BD_random[u])
        throughput_random_new[u] = math.log(1 + backscatter_SNR_random, 2)
    throughput_random = np.append(throughput_random, sum(throughput_random_new))

    # %% state
    Interfer_BD = np.zeros(No_BD)
    for u in range(0, No_BD):
        Interfer_BD[u] = np.sum(Pair[:, u] * Channel_gain_BD[u, Action_Index[u]])

    state_new = np.zeros((n_element_state, No_BD))
    #    for u in range(0, No_BD):
    #        state_new[0,u] = Interfered_BD[u]/SNR_BD_Avg[u]
    #        state_new[1,u]= Interfer_BD[u]
    #        state_new[2,u]= Action_Index[u]
    #        state_new[3:No_BD+3,u]= Channel_gain_BS_BD
    #        for v in range(0,No_BD):
    #            state_new[2*v*No_user+No_BD+3:(2*v+1)*No_user+No_BD+3,u]=Channel_gain_BD_user_last2[v*No_user:(v+1)*No_user]/SNR_BD_Avg[v]
    #            state_new[(2*v+1)*No_user+No_BD+3:(2*v+2)*No_user+No_BD+3,u]=Channel_gain_BD_user_last1[v*No_user:(v+1)*No_user]/SNR_BD_Avg[v]

    for u in range(0, No_BD):
        state_new[0, u] = Interfered_BD[u] / max(SNR_BD_Avg)
        state_new[1, u] = Interfer_BD[u] / max(SNR_BD_Avg)
        state_new[2, u] = Action_Index[u] / No_user
        state_new[3:No_user + 3, u] = Channel_gain_BS_BD[u] * Channel_gain_BD_user_last1[
                                                              u * No_user:(u + 1) * No_user] / max(SNR_BD_Avg)
        #        state_new[No_user+3:2*No_user+3,u]= Channel_gain_BS_BD[u]* Channel_gain_BD_user_last1[u*No_user:(u+1)*No_user]/SNR_BD_Avg[u]
        state_new[No_user + 3, u] = u / No_BD

    for u in range(0, No_BD):
        Memory_pool_set[u].append((state_old[:, u], Action_Index[u], reward[u], state_new[:, u]))

    i_observation = i_observation + 1

    state_old = state_new
    # print(state_old)
    while len(Memory_pool_set[1]) > n_memory_size:
        for u in range (0, No_BD):
            Memory_pool_set[u].popleft()

    # %% train network
    if i_observation >= n_mini_batch:

        for u in range (0,No_BD):
            mini_batch = random.sample(Memory_pool_set[u], n_mini_batch)
        # inputs = np.zeros((n_mini_batch, s_t.shape[1], s_t.shape[2], s_t.shape[3]))
            state_t, action_t, reward_t, state_t1 = zip(*mini_batch)
            state_t = list(state_t)
            state_shape = (n_mini_batch, n_element_state)
            state_t = np.reshape(state_t, state_shape)
            state_t1 = np.reshape(state_t1, state_shape)
        # print(state_t)
            targets = model_eval_set[u].predict(state_t)
            Q_sa = model_tar_set[u].predict(state_t1)
        #  print('begin')
        #   print(targets)
        # print(Q_sa)
        # print(len(action_t))
        # print(n_mini_batch)
        # targets[range(n_mini_batch), ][i_2][int(action_t[i_2])]=reward_t1[i_2]+gamma*np.max(Q_sa[i_2][:])
            for i in range(0, n_mini_batch):
                targets[i][int(action_t[i])] = reward_t[i] + gamma * np.max(Q_sa[i][:])
        # print(targets)
            loss_temp = model_eval_set[u].train_on_batch(state_t, targets)
            loss.append(loss_temp)
            if i_observation % 100 == 0:
                model_eval_set[u].save('model.h5')
                model_tar_set[u] = load_model('model.h5')

# %%Results and Plot

loss_len = int(math.floor((int(i_observation)) / 100))
# print(loss_len)
loss_plot = np.zeros(loss_len)

x_loss_plot = []
for i in range(0, loss_len):
    x_index = (i + 1) * 100
    x_loss_plot.append(x_index)
    loss_plot[i] = np.mean(loss[i * 100:(i * 100 + 100)])

# No_user_drl_average=[]
# time_slot_C=[]
# for i in range(0,len(No_user_drl)-199):
#	time_slot_C.append(i+200)
#	No_user_drl_average_temp=np.mean(No_user_drl[i:(i+200)])
#	No_user_drl_average.append(No_user_drl_average_temp)
#
# No_user_optimal_average=[]
# for i in range(0,len(No_user_optimal)-199):
#	No_user_optimal_average_temp=np.mean(No_user_optimal[i:(i+200)])
#	No_user_optimal_average.append(No_user_optimal_average_temp)


# No_user_random_average=[]
# for i in range(0,len(No_user_random)-199):
#	No_user_random_average_temp=np.mean(No_user_random[i:(i+200)])
#	No_user_random_average.append(No_user_random_average_temp)

throughput_drl_average = []
time_slot_C = []
for i in range(0, len(throughput_drl) - 199):
    time_slot_C.append(i + 200)
    throughput_drl_average_temp = np.mean(throughput_drl[i:(i + 200)])
    throughput_drl_average.append(throughput_drl_average_temp)

throughput_optimal_average = []
time_slot_C = []
for i in range(0, len(throughput_optimal) - 199):
    time_slot_C.append(i + 200)
    throughput_optimal_average_temp = np.mean(throughput_optimal[i:(i + 200)])
    throughput_optimal_average.append(throughput_optimal_average_temp)

throughput_optimal_sub_average=[]
time_slot_C=[]
for i in range(0,len(throughput_optimal_sub)-199):
	time_slot_C.append(i+200)
	throughput_optimal_sub_average_temp=np.mean(throughput_optimal_sub[i:(i+200)])
	throughput_optimal_sub_average.append(throughput_optimal_sub_average_temp)

throughput_random_average = []
time_slot_C = []
for i in range(0, len(throughput_random) - 199):
    time_slot_C.append(i + 200)
    throughput_random_average_temp = np.mean(throughput_random[i:(i + 200)])
    throughput_random_average.append(throughput_random_average_temp)

plt.figure(1)
plt.scatter(location_x, location_y, s=200, label='$User$', c='blue', marker='.', alpha=None, edgecolors='white')
plt.scatter(location_x_BD, location_y_BD, s=200, label='$BD$', c='red', marker='.', alpha=None, edgecolors='white')
plt.legend()
plt.show()

plt.figure(2)
plt.plot(x_loss_plot, loss_plot, 'r')
plt.show()

# plt.figure(3)
# plt.plot(time_slot_C,No_user_drl_average,'r', time_slot_C, No_user_optimal_average,'b', time_slot_C, No_user_random_average,'g')
# plt.show()

plt.figure(4)
plt.plot(time_slot_C, throughput_drl_average, 'r', time_slot_C, throughput_random_average, 'b', time_slot_C,
         throughput_optimal_average, 'g')
plt.show()

filename = 'drl_ave.json'
with open(filename, 'w') as f:
    json.dump(throughput_drl_average, f)

filename = 'optimal_ave.json'
with open(filename, 'w') as f:
    json.dump(throughput_optimal_average, f)

filename = 'random_ave.json'
with open(filename, 'w') as f:
    json.dump(throughput_random_average, f)

filename = 'time_slot.json'
with open(filename, 'w') as f:
    json.dump(time_slot_C, f)
