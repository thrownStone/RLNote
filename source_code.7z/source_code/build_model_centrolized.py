from keras.models import Sequential
from keras.layers import Dense, Activation, Dropout
from keras.optimizers import SGD, RMSprop, Adam
import keras.initializers

def build_model(n_shape):
    model = Sequential()
    model.add(Dense(256, activation='relu',input_shape=n_shape, kernel_initializer=keras.initializers.TruncatedNormal(mean=0, stddev=1, seed=None)))
    model.add(Dense(128, activation='relu', kernel_initializer=keras.initializers.TruncatedNormal(mean=0, stddev=1, seed=None)))
    model.add(Dense(64, activation='relu', kernel_initializer=keras.initializers.TruncatedNormal(mean=0, stddev=1, seed=None)))
    model.add(Dense(27, kernel_initializer=keras.initializers.TruncatedNormal(mean=0, stddev=1, seed=None)))
#    RMSprp=RMSprop(lr=0.005, rho=0.9, epsilon=1e-06,decay=1e-4)
    #sgd = SGD(lr=0.005, decay=1e-4, momentum=0.9, nesterov=True)
    #RMSPop=RMSprop(lr=0.0005, rho=0.9, epsilon=1e-06)
    adam=Adam(lr=0.005, beta_1=0.9, beta_2=0.999, epsilon=1e-08)
    model.compile(loss='mse',optimizer=adam, metrics=['accuracy'])
    return model