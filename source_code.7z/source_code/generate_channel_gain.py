import matplotlib.pyplot as plt
import numpy as np
import random
import math
import scipy.special

def generate_channel_gain(Average_channel_gain, Fading_input, T_time_slot):
    rho= 0.99 #scipy.special.jn(0, 2*math.pi*fd*T_time_slot)
   # print(rho)
    Fading_output = complex(rho * Fading_input.real + random.gauss(0, ((1-rho**2)/2)**(1/2)), rho * Fading_input.imag + random.gauss(0, ((1-rho**2)/2)**(1/2)))
    Fading_gain = Fading_output.real ** 2 + Fading_output.imag ** 2
    Channel_gain_output = Average_channel_gain * Fading_gain
    return Channel_gain_output, Fading_output
