import matplotlib.pyplot as plt
import numpy as np
import random
import math, generate_channel_gain,build_model
import scipy.special
from collections import deque
from keras.models import load_model

# average received SNR in dB

No_user = 3

threshold_dB = -40 #dB
threshold = 10**(threshold_dB/10) #dB
reflection_coef = 0.3

Prx_cell_Avg_dB = 10 #dB

Prx_cell_Avg=10**(Prx_cell_Avg_dB/10)
Noise = 1

Period_ratio = 50

T_time_slot=0.2*10**(-3) # duration of each time slot
n_symbols=5000 #T_time_slot/T_symbol

#m_ts_state=10 # memory of each state


Memory_pool=deque()
n_element_state=1+3*No_user ## state(t)=(channel gain(t), action(t-1), success/failed, signal strength(t-1), interference(t-1))
n_mini_batch=32
n_memory_size=500
n_training=10000
i_observation=0

n_network_input=(n_element_state,)
#print(n_network_input)
model_eval=build_model.build_model(n_network_input)
model_eval.save('model.h5') 
model_tar=load_model('model.h5')

epsilon=0.1
gamma=0.5
lambda_epsilon=0.0001
epsilon_min=0.005
loss=[]

# Action
Action_set= list(range(1,No_user+1))

#Channel Information

Channel_gain_BD_user_old = np.array([], dtype=float)
Fading_BD_user_old = np.array([], dtype=complex)
for u in range(0,No_user):
    Fading_BD_user=complex(2**(1/2)/2*random.gauss(0, 1),2**(1/2)/2*random.gauss(0, 1))
    Channel_gain_BD_user,Fading_BD_user = generate_channel_gain.generate_channel_gain(Prx_cell_Avg, Fading_BD_user, T_time_slot)
    Channel_gain_BD_user_old = np.append(Channel_gain_BD_user_old, float(Channel_gain_BD_user))
    Fading_BD_user_old = np.append(Fading_BD_user_old, complex(Fading_BD_user))

Channel_gain_BD_user_last2 =  Channel_gain_BD_user_old

Channel_gain_BD_user_old = np.array([], dtype=float)
Fading_BD_user_old = np.array([], dtype=complex)
for u in range(0,No_user):
    Fading_BD_user=complex(2**(1/2)/2*random.gauss(0, 1),2**(1/2)/2*random.gauss(0, 1))
    Channel_gain_BD_user,Fading_BD_user = generate_channel_gain.generate_channel_gain(Prx_cell_Avg, Fading_BD_user, T_time_slot)
    Channel_gain_BD_user_old = np.append(Channel_gain_BD_user_old, float(Channel_gain_BD_user))
    Fading_BD_user_old = np.append(Fading_BD_user_old, complex(Fading_BD_user))

Channel_gain_BD_user_last1 =  Channel_gain_BD_user_old

#Channel from BS to user  
Channel_gain_BS_user = np.array([], dtype=float)
for u in range(0,No_user):
    Fading_BS_user=complex(2**(1/2)/2*random.gauss(0, 1),2**(1/2)/2*random.gauss(0, 1))
    Channel_gain_BS_user_new = Prx_cell_Avg*(Fading_BS_user.real**2+Fading_BS_user.imag**2)
    Channel_gain_BS_user = np.append(Channel_gain_BS_user, float(Channel_gain_BS_user_new))
    
#Channel from BS to BD without transmission power    
Fading_BS_BD=complex(2**(1/2)/2*random.gauss(0, 1),2**(1/2)/2*random.gauss(0, 1))
Channel_gain_BS_BD = (Fading_BS_BD.real**2+Fading_BS_BD.imag**2)    

#The available interference of CDMA system last minutes
Action_Index=random.randint(0,len(Action_set)-1) 

#Qualified the interference 

related_SNR = reflection_coef**2*Channel_gain_BD_user_old[Action_Index-1]* Channel_gain_BS_BD/Channel_gain_BS_user[Action_Index-1]

backscatter_SNR = Period_ratio*reflection_coef**2*Channel_gain_BD_user_old[Action_Index-1]* Channel_gain_BS_BD

if related_SNR>=threshold:
    reward = 1/Period_ratio*math.log(1+backscatter_SNR,2)
else:
    reward = 0
    
#state
state_old=np.zeros(n_element_state)
state_old[0]=Channel_gain_BS_BD
state_old[1:No_user+1]=Channel_gain_BS_user
state_old[No_user+1:2*No_user+1]=Channel_gain_BD_user_last2
state_old[2*No_user+1:3*No_user+1]=Channel_gain_BD_user_last1


state_new = state_old

No_user_drl=[]
No_user_optimal = []
throughput_drl = []
while (i_observation<n_training):
    print(i_observation)
    if i_observation<n_mini_batch: 
        Action_Index=random.randint(0,len(Action_set)-1)
#        if  random.random()<epsilon:
#            Action_Index=random.randint(0,len(Action_set)-1)
    else:
        State_slot_t_temp=list(state_new[:])
        State_slot_t_temp_shape=(1, n_element_state)
        State_slot_t_temp=np.reshape(State_slot_t_temp,State_slot_t_temp_shape)
        q=model_eval.predict(State_slot_t_temp)
               # print('q')
              #  print(q)
        max_Q=np.argmax(q)
        Action_Index=max_Q
   
    # calculate DRL reward      
    
    related_SNR = reflection_coef**2*Channel_gain_BD_user_old[Action_Index-1]* Channel_gain_BS_BD/Channel_gain_BS_user[Action_Index-1]
    
    backscatter_SNR = Period_ratio*reflection_coef**2*Channel_gain_BD_user_old[Action_Index-1]* Channel_gain_BS_BD

    if related_SNR>=threshold:
        reward = 1/Period_ratio*math.log(1+backscatter_SNR,2)
    else:
        reward = 0

    Channel_gain_BD_user_old = np.array([], dtype=float)
    Fading_BD_user_old = np.array([], dtype=complex)
    for u in range(0,No_user):
        Fading_BD_user=complex(2**(1/2)/2*random.gauss(0, 1),2**(1/2)/2*random.gauss(0, 1))
        Channel_gain_BD_user,Fading_BD_user = generate_channel_gain.generate_channel_gain(Prx_cell_Avg, Fading_BD_user, T_time_slot)
        Channel_gain_BD_user_old = np.append(Channel_gain_BD_user_old, float(Channel_gain_BD_user))
        Fading_BD_user_old = np.append(Fading_BD_user_old, complex(Fading_BD_user))
 
    Channel_gain_BD_user_last2[Action_Index-1] =  Channel_gain_BD_user_last1[Action_Index-1]
    Channel_gain_BD_user_last1[Action_Index-1] =  Channel_gain_BD_user_old[Action_Index-1]

#Channel from BS to user  
    Channel_gain_BS_user = np.array([], dtype=float)
    for u in range(0,No_user):
        Fading_BS_user=complex(2**(1/2)/2*random.gauss(0, 1),2**(1/2)/2*random.gauss(0, 1))
        Channel_gain_BS_user_new = Prx_cell_Avg*(Fading_BS_user.real**2+Fading_BS_user.imag**2)
        Channel_gain_BS_user = np.append(Channel_gain_BS_user, float(Channel_gain_BS_user_new))
    
#Channel from BS to BD without transmission power    
    Fading_BS_BD=complex(2**(1/2)/2*random.gauss(0, 1),2**(1/2)/2*random.gauss(0, 1))
    Channel_gain_BS_BD = (Fading_BS_BD.real**2+Fading_BS_BD.imag**2)   
    
            
## calculate optimal access number
    related_SNR_optimal = reflection_coef**2*Channel_gain_BD_user_old* Channel_gain_BS_BD/Channel_gain_BS_user
    
    backscatter_SNR_optimal = Period_ratio*reflection_coef**2*Channel_gain_BD_user_old* Channel_gain_BS_BD

    
    
## calculate DRL access number    
    No_user_drl = np.append(No_user_drl, int(Action_Index))
    throughput_drl = np.append(throughput_drl, reward)      
    
    
    state_new=np.zeros(n_element_state)
    state_new[0]=Channel_gain_BS_BD
    state_new[1:No_user+1]=Channel_gain_BS_user
    state_new[No_user+1:2*No_user+1]=Channel_gain_BD_user_last2
    state_new[2*No_user+1:3*No_user+1]=Channel_gain_BD_user_last1

    Memory_pool.append((state_old[:], Action_Index, reward, state_new[:]))
    i_observation=i_observation+1

    state_old=state_new
    #print(state_old)
    while len(Memory_pool)>n_memory_size:
          Memory_pool.popleft()
    
## train network
    if i_observation>=n_mini_batch:

        mini_batch=random.sample(Memory_pool, n_mini_batch)
        #inputs = np.zeros((n_mini_batch, s_t.shape[1], s_t.shape[2], s_t.shape[3]))
        state_t, action_t, reward_t,state_t1=zip(*mini_batch)
        state_t=list(state_t)
        state_shape=(n_mini_batch,n_element_state)
        state_t=np.reshape(state_t,state_shape)
        state_t1=np.reshape(state_t1,state_shape)
       # print(state_t)
        targets=model_eval.predict(state_t)
       
        Q_sa=model_tar.predict(state_t1)
      #  print('begin')
     #   print(targets)
        #print(Q_sa)
       # print(len(action_t))
       # print(n_mini_batch)
       # targets[range(n_mini_batch), ][i_2][int(action_t[i_2])]=reward_t1[i_2]+gamma*np.max(Q_sa[i_2][:])
        for i in range(0,n_mini_batch):
                targets[i][int(action_t[i])]=reward_t[i]+gamma*np.max(Q_sa[i][:])
        #print(targets)
        loss_temp=model_eval.train_on_batch(state_t,targets) 

        loss.append(loss_temp)
        if i_observation%100 == 0:
           model_eval.save('model.h5') 
           model_tar=load_model('model.h5')



loss_len=int(math.floor((int(i_observation))/100))
#print(loss_len)
loss_plot=np.zeros(loss_len)

x_loss_plot=[]
for i in range(0,loss_len):
    x_index=(i+1)*100
    x_loss_plot.append(x_index)
    loss_plot[i]=np.mean(loss[i*100:(i*100+100)])

No_user_drl_average=[]
time_slot_C=[]
for i in range(0,len(No_user_drl)-199):
	time_slot_C.append(i+200)
	No_user_drl_average_temp=np.mean(No_user_drl[i:(i+200)])
	No_user_drl_average.append(No_user_drl_average_temp)

No_user_optimal_average=[]
for i in range(0,len(No_user_optimal)-199):
	No_user_optimal_average_temp=np.mean(No_user_optimal[i:(i+200)])
	No_user_optimal_average.append(No_user_optimal_average_temp)

plt.figure(1)
plt.plot(x_loss_plot,loss_plot,'r')
plt.show()

plt.figure(2)
plt.plot(time_slot_C,No_user_drl_average,'r')
plt.show()

throughput_drl_average=[]
time_slot_C=[]
for i in range(0,len(throughput_drl)-199):
	time_slot_C.append(i+200)
	throughput_drl_average_temp=np.mean(throughput_drl[i:(i+200)])
	throughput_drl_average.append(throughput_drl_average_temp)

plt.figure(3)
plt.plot(time_slot_C,throughput_drl_average,'r')
plt.show()

