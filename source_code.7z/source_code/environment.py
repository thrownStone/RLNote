import matplotlib.pyplot as plt
import numpy as np
import json

# average received SNR in dB

No_user = 3
No_BD = 3

# %%generate users and BDs

boundary = 100
#boundary1 = 30
inner_region = 20

loc_x = np.random.rand(No_user)
for u in range(0,No_user):
    if loc_x[u]>0.5:
        loc_x[u] = 1
    else:
        loc_x[u] = -1
loc_y = np.random.rand(No_user)
for u in range(0,No_user):
    if loc_y[u]>0.5:
        loc_y[u] = 1
    else:
        loc_y[u] = -1
loc_x_BD = np.random.rand(No_BD)
for u in range(0,No_BD):
    if loc_x_BD[u]>0.5:
        loc_x_BD[u] = 1
    else:
        loc_x_BD[u] = -1
loc_y_BD = np.random.rand(No_BD)
for u in range(0,No_BD):
    if loc_y_BD[u]>0.5:
        loc_y_BD[u] = 1
    else:
        loc_y_BD[u] = -1
location_x = loc_x*np.random.uniform(inner_region, boundary, No_user)
location_y = loc_y*np.random.uniform(inner_region, boundary, No_user)
location_x_BD = loc_x_BD*np.random.uniform(inner_region, boundary, No_BD)
location_y_BD = loc_y_BD*np.random.uniform(inner_region, boundary, No_BD)

plt.figure(1)
plt.scatter(location_x, location_y, s=200, label='$User$', c='blue', marker='.', alpha=None, edgecolors='white')
plt.scatter(location_x_BD, location_y_BD, s=200, label='$BD$', c='red', marker='.', alpha=None, edgecolors='white')
plt.legend()
plt.show()


location_x = location_x.tolist()
location_y = location_y.tolist()
location_x_BD = location_x_BD.tolist()
location_y_BD = location_y_BD.tolist()

filename = 'location_x.json'
with open(filename, 'w') as f:
    json.dump(location_x, f)

filename = 'location_y.json'
with open(filename, 'w') as f:
    json.dump(location_y, f)

filename = 'location_x_BD.json'
with open(filename, 'w') as f:
     json.dump(location_x_BD, f)

filename = 'location_y_BD.json'
with open(filename, 'w') as f:
    json.dump(location_y_BD, f)