import scipy.io as sio
import numpy as np
import json


filename = 'optimal_ave.json'
with open(filename, 'r') as f:
    data = json.load(f)

data = np.array(data)
sio.savemat('optimal_ave_distributed_1.mat', {'optimal_ave_distributed_1': data})

filename = 'time_slot.json'
with open(filename, 'r') as f:
    data = json.load(f)

data = np.array(data)
sio.savemat('time_slot_1.mat', {'time_slot_distributed_1': data})


filename = 'drl_semi_ave.json'
with open(filename, 'r') as f:
    data = json.load(f)

data = np.array(data)
sio.savemat('drl_semi_ave_distributed_1.mat', {'drl_semi_ave_distributed_1': data})

filename = 'drl_cen_ave.json'
with open(filename, 'r') as f:
    data = json.load(f)

data = np.array(data)
sio.savemat('drl_cen_ave_distributed_1.mat', {'drl_cen_ave_distributed_1': data})


filename = 'random_ave.json'
with open(filename, 'r') as f:
    data = json.load(f)

data = np.array(data)
sio.savemat('random_ave_distributed_1.mat', {'random_ave_distributed_1': data})
